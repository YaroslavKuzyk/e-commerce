/**
 * @prettier
 */
const dateGenerator = () => new Date().toISOString().substring(0, 10)

export default dateGenerator
